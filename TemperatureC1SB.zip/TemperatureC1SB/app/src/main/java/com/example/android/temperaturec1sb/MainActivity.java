package com.example.android.temperaturec1sb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    TextView textView;
    Button btn_C, btn_F;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.et_input);
        textView =(TextView) findViewById(R.id.tv_result);
        btn_C = (Button) findViewById(R.id.btn_C);
        btn_F = (Button) findViewById(R.id.btn_F);

        btn_C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = editText.getText().toString();



                if (input == null || input.equals("") ){
                    Toast.makeText(getApplicationContext(),"Please Enter Number", Toast.LENGTH_LONG).show();
                }
                else {
                    double doubleInput = Double.parseDouble(input);
                    double answer = celcius(doubleInput);
                    textView.setText(String.format("%.2f", answer) + " C");
                }
            }
        });


        btn_F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String input = editText.getText().toString();



                if (input == null || input.equals("") ){
                    Toast.makeText(getApplicationContext(),"Please Enter Number", Toast.LENGTH_LONG).show();
                }
                else {
                    double doubleInput = Double.parseDouble(input);
                    double answer = farenhite(doubleInput);
                    textView.setText(String.format("%.2f", answer) + " F");
                }

            }
        });

    }

    public double celcius(double input){
        return (input - 32) * 5/9;
    }

    public double farenhite(double input){
        return input * 9/5 + 32;
    }
}
